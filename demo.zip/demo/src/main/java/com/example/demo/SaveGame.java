package com.example.demo;

import java.io.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import java.io.IOException;
import java.util.Objects;
public class SaveGame {


    public void onSaveibuttonClick(int i) throws IOException, ClassNotFoundException{
       //method to save game
    }

    @FXML
    public void onBackButtonClick() throws IOException {
        //method to return to main menu
    }
    public void Loadgame() throws IOException {
        //method to return to load saved game
    }
}

